"""
CONFIG — change settings here, nowhere else in the codebase.
If you switch devices or want to try a different vision model,
this is the only file you should need to touch.
"""

# Which Ollama vision model to use for image description.
# To switch models: run `ollama pull <model_name>` for the new one,
# then just change this string. Nothing else in the code needs to change.
VISION_MODEL = "moondream"

# Alternative models to try if VISION_MODEL underperforms:
#   "llava-phi3"   -> ~2.9GB, stronger but slower on CPU-only machines
#   "llava"        -> larger, only recommended if you move to a machine with a GPU

# OCR settings
OCR_MIN_TEXT_LENGTH = 10  # below this char count, we assume it's an image (X-ray) not text

# Local server settings
HOST = "0.0.0.0"   # 0.0.0.0 lets other devices on the same network reach this server
PORT = 5000

# Storage
DB_FILE = "patient_records.json"
STORAGE_DIR = "patient_files"

# Timeout (seconds) for vision model calls — CPU-only inference can be slow
VISION_MODEL_TIMEOUT = 180

# --- Plain-language explanation step ---
# This runs AFTER local OCR/vision extraction + PII redaction, on the
# redacted text only. It calls an external API, so redacted (not raw)
# text is what gets sent off-device — see core.explain_with_api.
#
# Set the actual key as an environment variable in your shell, e.g.:
#   export OPENAI_API_KEY="sk-..."
# NEVER hardcode the key here or commit it to the repo.
EXPLAIN_API_PROVIDER = "openai"        # "openai" or "anthropic"
EXPLAIN_MODEL = "gpt-4o-mini"          # swap models by changing this string
EXPLAIN_API_KEY_ENV_VAR = "OPENAI_API_KEY"
EXPLAIN_API_TIMEOUT = 30               # seconds
