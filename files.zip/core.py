"""
CORE PROCESSING — the actual OCR / vision-model / redaction / storage logic.
Reads all tunable settings from config.py so nothing here needs to change
when you swap models or move devices.
"""

import base64
import json
import os
import re
from datetime import datetime, timezone

import pytesseract
import requests
from PIL import Image

import config


def extract_text_with_ocr(image_path):
    """Run Tesseract OCR on the image. Works well for typed/scanned report text."""
    img = Image.open(image_path)
    text = pytesseract.image_to_string(img)
    return text.strip()


def describe_with_vision_model(image_path, prompt="Describe any visible medical findings in this image."):
    """
    Call Ollama's local REST API directly (instead of shelling out to the CLI).
    This avoids terminal control-code garbage that leaks in when the `ollama run`
    CLI is captured programmatically, and returns clean JSON instead.
    Which model is used comes entirely from config.VISION_MODEL —
    change that one value to switch models, no code changes needed here.
    """
    try:
        with open(image_path, "rb") as f:
            image_b64 = base64.b64encode(f.read()).decode("utf-8")

        response = requests.post(
            f"{config.OLLAMA_API_URL}/api/generate",
            json={
                "model": config.VISION_MODEL,
                "prompt": prompt,
                "images": [image_b64],
                "stream": False,
            },
            timeout=config.VISION_MODEL_TIMEOUT,
        )
        response.raise_for_status()
        return response.json().get("response", "").strip()
    except Exception as e:
        return f"[vision model error: {e}]"


def redact_pii(text):
    """Local info-blocking step: strip obvious PII before anything leaves this machine."""
    redacted = text

    # ID numbers (6+ consecutive digits, e.g. patient/MRN IDs)
    redacted = re.sub(r"\b\d{6,}\b", "[ID_REDACTED]", redacted)

    # Phone numbers (Indian 10-digit, with or without +91 / 0 prefix)
    redacted = re.sub(r"\b(?:\+91[-\s]?|0)?\d{10}\b", "[PHONE_REDACTED]", redacted)

    # Dates
    redacted = re.sub(r"\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b", "[DATE_REDACTED]", redacted)

    # Labeled fields (name, DOB, ID, MRN)
    redacted = re.sub(
        r"(?im)^(patient name|name|dob|date of birth|id number|mrn|phone|contact)\s*:.*$",
        r"\1: [REDACTED]",
        redacted,
    )

    # Hospital name(s) from config — add your hospital's name/abbreviations there
    for hospital_name in config.HOSPITAL_NAMES:
        if hospital_name:
            redacted = re.sub(re.escape(hospital_name), "[HOSPITAL_REDACTED]", redacted, flags=re.IGNORECASE)

    # Generic pattern: "<Capitalized Words> Hospital/Clinic/Medical Center"
    redacted = re.sub(
        r"\b([A-Z][a-zA-Z]+(?:\s[A-Z][a-zA-Z]+){0,3}\s(?:Hospital|Clinic|Medical Center|Medical College))\b",
        "[HOSPITAL_REDACTED]",
        redacted,
    )

    return redacted


SIMPLIFICATION_SYSTEM_PROMPT = """You are a medical report simplifier for elderly patients.
Rules you must always follow:
1. Explain findings in simple, everyday words. No unexplained medical jargon.
2. Never diagnose. Never suggest treatment. Only explain what the report/image says in plain language.
3. Keep the tone calm and factual — not alarming, not falsely reassuring.
4. Do not comment on or speculate about any personal identifying information.
5. Always end your response with exactly this line: "Please discuss this with your doctor."
"""


def simplify_with_openai(redacted_text):
    """
    Send the already-redacted text to the OpenAI API for plain-language simplification.
    Only ever called with text that has already passed through redact_pii() —
    no raw/unredacted text should reach this function.
    Returns (simplified_text, status) where status is "sent" or "error".
    """
    if not config.OPENAI_API_KEY:
        return "[OpenAI API key not set — export OPENAI_API_KEY as an environment variable]", "error"

    try:
        response = requests.post(
            "https://api.openai.com/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {config.OPENAI_API_KEY}",
                "Content-Type": "application/json",
            },
            json={
                "model": config.OPENAI_MODEL,
                "messages": [
                    {"role": "system", "content": SIMPLIFICATION_SYSTEM_PROMPT},
                    {"role": "user", "content": redacted_text},
                ],
                "temperature": 0.3,
            },
            timeout=30,
        )
        response.raise_for_status()
        data = response.json()
        simplified = data["choices"][0]["message"]["content"].strip()
        return simplified, "sent"
    except Exception as e:
        return f"[OpenAI API error: {e}]", "error"


def load_db():
    if os.path.exists(config.DB_FILE):
        with open(config.DB_FILE, "r") as f:
            return json.load(f)
    return []


def save_db(records):
    with open(config.DB_FILE, "w") as f:
        json.dump(records, f, indent=2)


def process_record(patient_id, photo_path, report_path):
    """
    Full pipeline for one patient record:
    OCR attempt -> fallback to vision model -> redact -> save -> stage for OpenAI step.
    Returns the saved record as a dict.
    """
    os.makedirs(config.STORAGE_DIR, exist_ok=True)

    raw_ocr_text = extract_text_with_ocr(report_path)

    if len(raw_ocr_text) < config.OCR_MIN_TEXT_LENGTH:
        raw_text = describe_with_vision_model(report_path)
        extraction_method = f"vision_model:{config.VISION_MODEL}"
    else:
        raw_text = raw_ocr_text
        extraction_method = "ocr"

    redacted_text = redact_pii(raw_text)
    simplified_text, openai_status = simplify_with_openai(redacted_text)

    record = {
        "patient_id": patient_id,
        "photo_path": photo_path,
        "report_path": report_path,
        "extraction_method": extraction_method,
        "raw_text": raw_text,
        "redacted_text": redacted_text,
        "simplified_text": simplified_text,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "openai_status": openai_status,
    }

    records = load_db()
    records.append(record)
    save_db(records)

    return record
