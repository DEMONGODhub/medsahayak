"""
LOCAL FACE MATCHING (patient re-identification across visits)
----------------------------------------------------------------
DESIGN NOTE: patient photos are sensitive biometric data. Instead of sending
them to any external service (e.g. Google Vision) for identification, this
stays 100% local — consistent with the rest of this pipeline's local-first
design. It uses OpenCV's built-in face detector (no heavy extra dependencies)
plus a simple similarity comparison — NOT deep-learning-grade face
recognition. Treat a "match" as a hint for staff to confirm ("this might be
the same person as an earlier visit"), not a certainty. Good enough for a
hackathon demo of the concept; would need a proper face-recognition model
for real deployment.

Requires: opencv-python (pip install opencv-python)
"""

import json
import os

import cv2
import numpy as np

import config

FACE_DB_FILE = os.path.join(config.STORAGE_DIR, "face_embeddings.json")
FACE_SIZE = (100, 100)
MATCH_THRESHOLD = 0.85  # cosine similarity above this = likely the same person

_face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")


def _load_db():
    if os.path.exists(FACE_DB_FILE):
        with open(FACE_DB_FILE) as f:
            return json.load(f)
    return []


def _save_db(entries):
    os.makedirs(config.STORAGE_DIR, exist_ok=True)
    with open(FACE_DB_FILE, "w") as f:
        json.dump(entries, f, indent=2)


def _extract_embedding(image_path):
    """Detect the largest face in the image and return a flattened, normalized vector."""
    img = cv2.imread(image_path)
    if img is None:
        return None
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    faces = _face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)
    if len(faces) == 0:
        return None
    x, y, w, h = max(faces, key=lambda f: f[2] * f[3])  # largest detected face
    face = gray[y:y + h, x:x + w]
    face = cv2.resize(face, FACE_SIZE)
    face = cv2.equalizeHist(face)
    vector = face.flatten().astype("float32")
    norm = np.linalg.norm(vector)
    if norm > 0:
        vector = vector / norm
    return vector.tolist()


def find_match(image_path):
    """
    Check this photo against all previously enrolled faces.
    Returns {"folder": ..., "similarity": ...} for the best match above
    threshold, or None if no confident match / no face detected.
    """
    vector = _extract_embedding(image_path)
    if vector is None:
        return None

    entries = _load_db()
    best = None
    v = np.array(vector)
    for entry in entries:
        stored = np.array(entry["vector"])
        similarity = float(np.dot(v, stored))  # both normalized -> cosine similarity
        if best is None or similarity > best["similarity"]:
            best = {"folder": entry["folder"], "similarity": round(similarity, 3)}

    if best and best["similarity"] >= MATCH_THRESHOLD:
        return best
    return None


def enroll(image_path, folder):
    """Store this photo's face embedding, linked to a patient folder, for future matching."""
    vector = _extract_embedding(image_path)
    if vector is None:
        return False
    entries = _load_db()
    entries.append({"folder": folder, "vector": vector})
    _save_db(entries)
    return True
