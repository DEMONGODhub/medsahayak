"""
CORE PROCESSING — OCR / vision-model / redaction / explanation / storage logic.
Reads all tunable settings from config.py so nothing here needs to change
when you swap models, providers, or move devices.

Note: redact_pii() runs BEFORE explain_with_api() in the pipeline below —
only redacted text ever leaves the device via the external API call.
"""

import json
import os
import re
import subprocess
from datetime import datetime, timezone

import pytesseract
import requests
from PIL import Image

import config
import prompts
import runtime_flags


def extract_text_with_ocr(image_path):
    """Run Tesseract OCR on the image. Works well for typed/scanned report text."""
    img = Image.open(image_path)
    text = pytesseract.image_to_string(img)
    return text.strip()


def describe_with_vision_model(image_path, prompt="Describe any visible medical findings in this image."):
    """
    Run the configured Ollama vision model on the image.
    Which model is used comes entirely from config.VISION_MODEL —
    change that one value to switch models, no code changes needed here.
    """
    try:
        result = subprocess.run(
            ["ollama", "run", config.VISION_MODEL, prompt, image_path],
            capture_output=True,
            text=True,
            timeout=config.VISION_MODEL_TIMEOUT,
        )
        if result.returncode != 0:
            return f"[vision model error: {result.stderr.strip()}]"
        return result.stdout.strip()
    except Exception as e:
        return f"[vision model error: {e}]"


def redact_pii(text):
    """Local info-blocking step: strip obvious PII before anything leaves this machine."""
    redacted = text
    redacted = re.sub(r"\b\d{6,}\b", "[ID_REDACTED]", redacted)
    redacted = re.sub(r"\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b", "[DATE_REDACTED]", redacted)
    redacted = re.sub(
        r"(?im)^(patient name|name|dob|date of birth|id number|mrn)\s*:.*$",
        r"\1: [REDACTED]",
        redacted,
    )
    return redacted


def _call_openai(system_prompt, redacted_text, api_key):
    response = requests.post(
        "https://api.openai.com/v1/chat/completions",
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        json={
            "model": config.EXPLAIN_MODEL,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": redacted_text},
            ],
            "temperature": 0.2,
        },
        timeout=config.EXPLAIN_API_TIMEOUT,
    )
    response.raise_for_status()
    return response.json()["choices"][0]["message"]["content"]


def _call_anthropic(system_prompt, redacted_text, api_key):
    response = requests.post(
        "https://api.anthropic.com/v1/messages",
        headers={
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
            "Content-Type": "application/json",
        },
        json={
            "model": config.EXPLAIN_MODEL,
            "max_tokens": 1000,
            "system": system_prompt,
            "messages": [{"role": "user", "content": redacted_text}],
        },
        timeout=config.EXPLAIN_API_TIMEOUT,
    )
    response.raise_for_status()
    return response.json()["content"][0]["text"]


_PROVIDERS = {
    "openai": _call_openai,
    "anthropic": _call_anthropic,
}


def explain_with_api(redacted_text, extraction_method):
    """
    Send already-redacted text to the configured external LLM for a
    plain-language explanation. Only ever call this with redacted_text —
    never raw_text — since this step leaves the device.

    Returns (explanation, status) where status is "sent" or an
    "error: <reason>" string that gets stored in the record for debugging.
    """
    api_key = os.environ.get(config.EXPLAIN_API_KEY_ENV_VAR)
    if not api_key:
        return None, f"error: {config.EXPLAIN_API_KEY_ENV_VAR} not set"

    call_fn = _PROVIDERS.get(config.EXPLAIN_API_PROVIDER)
    if call_fn is None:
        return None, f"error: unknown EXPLAIN_API_PROVIDER '{config.EXPLAIN_API_PROVIDER}'"

    system_prompt = (
        prompts.XRAY_SCREENING_EXPLAINER_PROMPT
        if extraction_method.startswith("vision_model")
        else prompts.REPORT_EXPLAINER_PROMPT
    )

    try:
        explanation = call_fn(system_prompt, redacted_text, api_key)
        return explanation, "sent"
    except Exception as e:
        return None, f"error: {e}"


def load_db():
    if os.path.exists(config.DB_FILE):
        with open(config.DB_FILE, "r") as f:
            return json.load(f)
    return []


def save_db(records):
    with open(config.DB_FILE, "w") as f:
        json.dump(records, f, indent=2)


def process_record(patient_id, photo_path, report_paths):
    """
    Full pipeline for one patient record. report_paths is a LIST — one or
    more images (e.g. multiple pages of a report, or a report + an X-ray
    together). Each is OCR'd or described individually, then combined.
    OCR attempt -> fallback to vision model -> redact -> explain -> detect
    conditions -> save. Returns the saved record as a dict.
    """
    os.makedirs(config.STORAGE_DIR, exist_ok=True)

    if isinstance(report_paths, str):
        report_paths = [report_paths]

    flags = runtime_flags.load_flags()

    text_parts = []
    methods_used = []
    for report_path in report_paths:
        raw_ocr_text = extract_text_with_ocr(report_path)
        if len(raw_ocr_text) < config.OCR_MIN_TEXT_LENGTH:
            if flags["vision_model_enabled"]:
                text_parts.append(describe_with_vision_model(report_path))
                methods_used.append(f"vision_model:{config.VISION_MODEL}")
            else:
                text_parts.append("[vision model disabled by command center — no text extracted from this image]")
                methods_used.append("vision_model_disabled")
        else:
            text_parts.append(raw_ocr_text)
            methods_used.append("ocr")

    raw_text = "\n\n---\n\n".join(text_parts)
    extraction_method = "+".join(dict.fromkeys(methods_used))  # de-duplicated, order-preserved

    redacted_text = redact_pii(raw_text)

    if flags["explanation_enabled"]:
        explanation, openai_status = explain_with_api(redacted_text, extraction_method)
    else:
        explanation, openai_status = None, "disabled_by_command_center"

    conditions = detect_conditions(explanation or redacted_text)

    record = {
        "patient_id": patient_id,
        "photo_path": photo_path,
        "report_paths": report_paths,
        "extraction_method": extraction_method,
        "raw_text": raw_text,
        "redacted_text": redacted_text,
        "explanation": explanation,
        "conditions": conditions,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "openai_status": openai_status,
    }

    records = load_db()
    records.append(record)
    save_db(records)

    return record


def detect_conditions(text):
    """
    Look for mentions of tracked condition categories (config.CONDITION_KEYWORDS)
    in the AI's explanation, and flag ones that sound ABNORMAL (high/low/elevated
    wording nearby) — not every mention, so a normal reading doesn't get flagged.
    This is simple keyword matching, not clinical interpretation; it only decides
    which summary cards to show, it never appears in anything sent to the patient
    as a diagnosis.
    """
    if not text:
        return []

    text_lower = text.lower()
    high_words = ["high", "elevated", "increased", "raised", "above normal"]
    low_words = ["low", "decreased", "reduced", "below normal"]

    found = []
    seen_labels = set()
    for label, keywords in config.CONDITION_KEYWORDS.items():
        if label in seen_labels:
            continue
        for kw in keywords:
            idx = text_lower.find(kw)
            if idx == -1:
                continue
            window = text_lower[max(0, idx - 40): idx + 40]
            if any(w in window for w in high_words):
                found.append({"label": label, "status": "High"})
                seen_labels.add(label)
            elif any(w in window for w in low_words):
                found.append({"label": label, "status": "Low"})
                seen_labels.add(label)
            break

    return found


def chat_with_api(message):
    """
    General-purpose chat (the 'ask me anything' bar), separate from report
    explanation. The message is redacted first in case the patient types
    anything sensitive, then sent to the same configured LLM provider.
    """
    api_key = os.environ.get(config.EXPLAIN_API_KEY_ENV_VAR)
    if not api_key:
        return None, f"error: {config.EXPLAIN_API_KEY_ENV_VAR} not set"

    call_fn = _PROVIDERS.get(config.EXPLAIN_API_PROVIDER)
    if call_fn is None:
        return None, f"error: unknown EXPLAIN_API_PROVIDER '{config.EXPLAIN_API_PROVIDER}'"

    redacted_message = redact_pii(message)

    try:
        reply = call_fn(prompts.CHAT_ASSISTANT_PROMPT, redacted_message, api_key)
        return reply, "sent"
    except Exception as e:
        return None, f"error: {e}"
