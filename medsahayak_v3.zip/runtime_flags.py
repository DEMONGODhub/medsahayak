"""
RUNTIME FLAGS — feature toggles shared between app.py (the server) and
command_center.py (the desktop control panel). Stored in a small JSON file
so both processes stay in sync without needing to talk to each other directly.
"""

import json
import os

FLAGS_FILE = "runtime_flags.json"

DEFAULT_FLAGS = {
    "face_matching_enabled": True,
    "explanation_enabled": True,   # if off, skip the external AI call, store redacted text only
    "vision_model_enabled": True,  # if off, only OCR runs — vision fallback is skipped
}


def load_flags():
    if os.path.exists(FLAGS_FILE):
        with open(FLAGS_FILE) as f:
            data = json.load(f)
        merged = {**DEFAULT_FLAGS, **data}
        return merged
    return dict(DEFAULT_FLAGS)


def save_flags(flags):
    with open(FLAGS_FILE, "w") as f:
        json.dump(flags, f, indent=2)


def set_flag(name, value):
    flags = load_flags()
    flags[name] = value
    save_flags(flags)
    return flags
