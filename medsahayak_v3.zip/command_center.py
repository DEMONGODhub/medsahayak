"""
COMMAND CENTER — desktop control panel (separate from the browser page).
Run this alongside app.py (in a different terminal) to toggle features on/off
live, and watch usage stats, without touching the browser UI at all.

Run with:
    python3 command_center.py
"""

import tkinter as tk
from tkinter import ttk

import runtime_flags
import stats

REFRESH_MS = 3000


class CommandCenter:
    def __init__(self, root):
        self.root = root
        root.title("MedSahayak — Command Center")
        root.geometry("420x420")

        tk.Label(root, text="MedSahayak Command Center", font=("Arial", 16, "bold")).pack(pady=(14, 4))
        tk.Label(root, text="Controls the running local AI server (app.py)", fg="#666").pack(pady=(0, 14))

        # ---- Feature toggles ----
        toggles_frame = tk.LabelFrame(root, text="Feature toggles", padx=12, pady=10)
        toggles_frame.pack(fill="x", padx=16, pady=8)

        flags = runtime_flags.load_flags()

        self.face_matching_var = tk.BooleanVar(value=flags["face_matching_enabled"])
        self.explanation_var = tk.BooleanVar(value=flags["explanation_enabled"])
        self.vision_model_var = tk.BooleanVar(value=flags["vision_model_enabled"])

        ttk.Checkbutton(
            toggles_frame, text="Face matching (repeat-visit detection)",
            variable=self.face_matching_var,
            command=lambda: self._set_flag("face_matching_enabled", self.face_matching_var.get()),
        ).pack(anchor="w", pady=4)

        ttk.Checkbutton(
            toggles_frame, text="AI explanation step (sends redacted text out)",
            variable=self.explanation_var,
            command=lambda: self._set_flag("explanation_enabled", self.explanation_var.get()),
        ).pack(anchor="w", pady=4)

        ttk.Checkbutton(
            toggles_frame, text="Vision model fallback (for image-only reports/X-rays)",
            variable=self.vision_model_var,
            command=lambda: self._set_flag("vision_model_enabled", self.vision_model_var.get()),
        ).pack(anchor="w", pady=4)

        # ---- Live stats ----
        stats_frame = tk.LabelFrame(root, text="Live usage", padx=12, pady=10)
        stats_frame.pack(fill="x", padx=16, pady=8)

        self.connected_label = tk.Label(stats_frame, text="Connected devices: —", anchor="w")
        self.connected_label.pack(fill="x", pady=2)

        self.processing_label = tk.Label(stats_frame, text="Currently processing: —", anchor="w")
        self.processing_label.pack(fill="x", pady=2)

        self.total_label = tk.Label(stats_frame, text="Total requests: —", anchor="w")
        self.total_label.pack(fill="x", pady=2)

        tk.Label(root, text="Changes here apply to the next request the server handles.\nNo restart needed.", fg="#888", font=("Arial", 9)).pack(pady=(10, 4))

        self._refresh_stats()

    def _set_flag(self, name, value):
        runtime_flags.set_flag(name, value)

    def _refresh_stats(self):
        try:
            data = stats.get_stats()
            self.connected_label.config(text=f"Connected devices (last 5 min): {data['connected_devices_recent']}")
            self.processing_label.config(text=f"Currently processing: {data['currently_processing']}")
            self.total_label.config(text=f"Total requests: {data['total_requests']}")
        except Exception as e:
            self.connected_label.config(text=f"Stats unavailable: {e}")
        self.root.after(REFRESH_MS, self._refresh_stats)


if __name__ == "__main__":
    root = tk.Tk()
    app = CommandCenter(root)
    root.mainloop()
