"""
LOCAL HOSTING SERVER
---------------------
Wraps the OCR + vision-model + explanation pipeline behind a local API, plus:
  - per-patient folder storage (searchable by patient or family member name)
  - local face matching to flag possible repeat patients
  - usage stats + a live admin dashboard at /admin

Run with:
    python3 app.py

Then from any device on the same network:
    http://<this-pc-ip>:5000          <- upload page
    http://<this-pc-ip>:5000/admin    <- usage dashboard
"""

import os

from flask import Flask, request, jsonify, render_template

import config
import core
import face_id
import runtime_flags
import stats
import storage

app = Flask(__name__)


@app.before_request
def _track_device():
    stats.record_request(request.remote_addr)


@app.route("/", methods=["GET"])
def home():
    """Upload page."""
    return render_template("index.html")


@app.route("/admin", methods=["GET"])
def admin():
    """Live usage dashboard for staff/management."""
    return render_template("admin.html")


@app.route("/admin/stats", methods=["GET"])
def admin_stats():
    return jsonify(stats.get_stats())


@app.route("/health", methods=["GET"])
def health():
    """Quick check that the server + config are alive."""
    return jsonify({
        "status": "ok",
        "vision_model": config.VISION_MODEL,
    })


@app.route("/search", methods=["GET"])
def search():
    """Search previously seen patients by name (patient's own or a family member's)."""
    query = request.args.get("q", "")
    return jsonify(storage.search_patients(query))


@app.route("/chat", methods=["POST"])
def chat():
    """General 'ask me anything' chat — separate from report explanation."""
    data = request.get_json(force=True, silent=True) or {}
    message = data.get("message", "").strip()
    if not message:
        return jsonify({"error": "message is required"}), 400

    reply, status = core.chat_with_api(message)
    return jsonify({"reply": reply, "status": status})


@app.route("/process", methods=["POST"])
def process():
    """
    Accepts patient_id, patient_name, optional family_member_name, a photo,
    and one or more report/X-ray images. Runs the full local pipeline, files
    the record under a per-patient folder, checks for a possible repeat-visit
    face match, and returns the saved record as JSON.
    """
    patient_id = request.form.get("patient_id")
    patient_name = request.form.get("patient_name")
    family_member_name = request.form.get("family_member_name") or None
    photo_file = request.files.get("photo")
    report_files = request.files.getlist("report")

    if not patient_id or not patient_name or not photo_file or not report_files:
        return jsonify({"error": "patient_id, patient_name, photo, and at least one report image are all required"}), 400

    stats.start_processing()
    try:
        folder = storage.get_or_create_patient_folder(patient_name, family_member_name)

        photo_path = os.path.join(folder, f"photo_{photo_file.filename}")
        photo_file.save(photo_path)

        report_paths = []
        for i, report_file in enumerate(report_files):
            report_path = os.path.join(folder, f"report_{i}_{report_file.filename}")
            report_file.save(report_path)
            report_paths.append(report_path)

        # Check if this face matches someone already enrolled, then enroll it either way
        # (skipped entirely if turned off from the command center)
        flags = runtime_flags.load_flags()
        face_match = None
        if flags["face_matching_enabled"]:
            face_match = face_id.find_match(photo_path)
            face_id.enroll(photo_path, folder)

        record = core.process_record(patient_id, photo_path, report_paths)
        record["patient_name"] = patient_name
        record["family_member_name"] = family_member_name
        record["patient_folder"] = folder
        record["possible_repeat_visit_match"] = face_match

        # process_record already saved the record once via core.save_db —
        # update that same entry with the extra fields we just added
        records = core.load_db()
        records[-1] = record
        core.save_db(records)

        return jsonify(record)
    finally:
        stats.end_processing()


@app.route("/records", methods=["GET"])
def list_records():
    """Return all stored records — useful for a management view."""
    return jsonify(core.load_db())


if __name__ == "__main__":
    print(f"Starting local AI server with vision model: {config.VISION_MODEL}")
    app.run(host=config.HOST, port=config.PORT, threaded=True)
