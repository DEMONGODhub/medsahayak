"""
PATIENT STORAGE — organizes files into per-patient folders so records can be
found again next time by the patient's own name OR a family member's name,
instead of a single flat folder of uploads.

Folder layout:
    patient_files/
        <patient_folder_slug>/
            info.json          <- names, created date
            photo_<filename>
            report_<filename>

A name index (name_index.json) maps every known name (patient's own name AND
any linked family member name) to their folder, so searching by either works.
"""

import json
import os
import re
import unicodedata
from datetime import datetime, timezone

import config

INDEX_FILE = os.path.join(config.STORAGE_DIR, "name_index.json")


def _slugify(name):
    """Turn a name into a safe folder name: lowercase, no special characters."""
    name = unicodedata.normalize("NFKD", name).encode("ascii", "ignore").decode("ascii")
    name = re.sub(r"[^a-zA-Z0-9]+", "_", name).strip("_").lower()
    return name or "unknown"


def _load_index():
    if os.path.exists(INDEX_FILE):
        with open(INDEX_FILE, "r") as f:
            return json.load(f)
    return {}


def _save_index(index):
    os.makedirs(config.STORAGE_DIR, exist_ok=True)
    with open(INDEX_FILE, "w") as f:
        json.dump(index, f, indent=2)


def get_or_create_patient_folder(patient_name, family_member_name=None):
    """
    Returns the folder path for this patient. Reuses an existing folder if
    this name (or the given family member's name) was seen before —
    otherwise creates a new one.
    """
    index = _load_index()
    patient_key = _slugify(patient_name)
    family_key = _slugify(family_member_name) if family_member_name else None

    folder = index.get(patient_key) or (index.get(family_key) if family_key else None)

    if not folder:
        folder = os.path.join(config.STORAGE_DIR, patient_key)
        os.makedirs(folder, exist_ok=True)
        info = {
            "patient_name": patient_name,
            "family_member_name": family_member_name,
            "created": datetime.now(timezone.utc).isoformat(),
        }
        with open(os.path.join(folder, "info.json"), "w") as f:
            json.dump(info, f, indent=2)
    else:
        os.makedirs(folder, exist_ok=True)

    # Register both names so searching either one finds this folder next time
    index[patient_key] = folder
    if family_key:
        index[family_key] = folder
    _save_index(index)

    return folder


def search_patients(query):
    """Return all known names (and their folders) whose name contains the query string."""
    index = _load_index()
    query = query.lower().strip()
    matches = []
    seen_folders = set()
    for name_key, folder in index.items():
        if query and query in name_key and folder not in seen_folders:
            info_path = os.path.join(folder, "info.json")
            info = {}
            if os.path.exists(info_path):
                with open(info_path) as f:
                    info = json.load(f)
            matches.append({"folder": folder, **info})
            seen_folders.add(folder)
    return matches
