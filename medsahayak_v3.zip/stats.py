"""
USAGE STATS — powers the admin dashboard:
  - which devices (by IP) have used the system, and how many times
  - how many devices have been active recently ("connected")
  - how many requests are being processed right now ("currently using")
Stored in usage_stats.json, updated on every request via app.py's before_request hook.
"""

import json
import os
import threading
from datetime import datetime, timezone

import config

STATS_FILE = "usage_stats.json"
CONNECTED_WINDOW_SECONDS = 300  # a device counts as "connected" if seen in the last 5 minutes

_lock = threading.Lock()
_in_progress = 0  # how many /process requests are actively running right now


def _load():
    if os.path.exists(STATS_FILE):
        with open(STATS_FILE) as f:
            return json.load(f)
    return {"devices": {}, "total_requests": 0}


def _save(data):
    with open(STATS_FILE, "w") as f:
        json.dump(data, f, indent=2)


def record_request(ip):
    """Call this on every incoming request to log which device made it."""
    with _lock:
        data = _load()
        now = datetime.now(timezone.utc).isoformat()
        device = data["devices"].get(ip, {"first_seen": now, "request_count": 0})
        device["last_seen"] = now
        device["request_count"] += 1
        data["devices"][ip] = device
        data["total_requests"] += 1
        _save(data)


def start_processing():
    """Call when a /process request begins."""
    global _in_progress
    with _lock:
        _in_progress += 1


def end_processing():
    """Call when a /process request finishes (success or error)."""
    global _in_progress
    with _lock:
        _in_progress = max(0, _in_progress - 1)


def get_stats():
    data = _load()
    now = datetime.now(timezone.utc)
    devices = data["devices"]
    connected = 0
    for ip, info in devices.items():
        last_seen = datetime.fromisoformat(info["last_seen"])
        if (now - last_seen).total_seconds() < CONNECTED_WINDOW_SECONDS:
            connected += 1
    return {
        "total_devices_ever": len(devices),
        "connected_devices_recent": connected,
        "currently_processing": _in_progress,
        "total_requests": data["total_requests"],
        "devices": devices,
    }
